
<?php $__env->startSection('title','Section List'); ?>
<?php $__env->startSection('script_css'); ?>
<link href="<?php echo e(asset('backEnd/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<h6 class="mb-0 text-uppercase">User List</h6>
				<hr/>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
						  <?php if(Session::has('success_message')): ?>
							<div class="alert alert-success border-0 bg-success alert-dismissible fade show">
								<div class="text-white"><?php echo e(Session::get('success_message')); ?></div>
								<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
							</div>
						  <?php endif; ?>
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th width="10%">SL#</th>
										<th>Name</th>
										<th>Email</th>
										<th>Mobile</th>
										<th>City</th>
										<th>Country</th>
										<th>Status</th>
									</tr>
								</thead>
								<tbody>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
										<td><?php echo e($key+1); ?></td>
										<td><?php echo e($user['name']); ?></td>
                                        <td><?php echo e($user['email']); ?></td>
                                        <td><?php echo e($user['mobile']); ?></td>
                                        <td><?php echo e($user['city']); ?></td>
                                        <td><?php echo e($user['country']); ?></td>
										<td>
											<?php if($user['status'] ==1): ?>
												<a class="updateUserStatus" id="user-<?php echo e($user['id']); ?>" user_id="<?php echo e($user['id']); ?>" href="javascript:void(0)">Active</a>  
											<?php else: ?>
												<a class="updateUserStatus" id="user-<?php echo e($user['id']); ?>" user_id="<?php echo e($user['id']); ?>" href="javascript:void(0)">Inactive</a>  
											<?php endif; ?>
										</td>
			
									</tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								</tbody>
							</table>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		<!--end page wrapper -->
		
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script_js"); ?>
<script src="<?php echo e(asset('backEnd/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\user\users.blade.php ENDPATH**/ ?>