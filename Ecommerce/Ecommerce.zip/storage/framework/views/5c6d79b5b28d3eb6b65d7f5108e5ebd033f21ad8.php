
<?php $__env->startSection('front_css'); ?>
<style>
form.cmxform label.error, label.error {
    color: red;
    font-style: italic;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">Login</li>
    </ul>
	<h3> Login / Register</h3>	
	<hr class="soft"/>
	
	<div class="row">
	<?php if(Session::has('success_message')): ?>
     <div class="alert alert-success" role="alert">
       <?php echo e(Session::get('success_message')); ?>

       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>
     <?php endif; ?>
	<?php if(Session::has('error_message')): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e(Session::get('error_message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php endif; ?>
		<div class="span4">
			<div class="well">
			<h5>Forgot Password</h5><br/>
			Enter your Email to get the new password.<br/><br/><br/>
			<form id="forgotPasswordForm" action="<?php echo e(url('forgot-password')); ?>" method="post">
				<?php echo csrf_field(); ?>
			 
              <div class="control-group">
				<label class="control-label" for="email">E-mail</label>
				<div class="controls">
				  <input class="span3" name="email" type="text" id="email" placeholder="Enter Email" required="">
				</div>
			  </div>
             
			  <div class="controls">
			  <button type="submit" class="btn block">Submit</button>
			  </div>
			</form>
		</div>
		</div>
		<div class="span1"> &nbsp;</div>
		<div class="span4">
			<div class="well">
			<h5>ALREADY REGISTERED ?</h5>
			<form id="LoginForm" action="<?php echo e(url('/login')); ?>" method="post">
				<?php echo csrf_field(); ?>
			  <div class="control-group">
				<label class="control-label" for="email">Email</label>
				<div class="controls">
				  <input class="span3" name="email" type="text" id="email" placeholder="Email">
				</div>
			  </div>
			  <div class="control-group">
				<label class="control-label" for="password">Password</label>
				<div class="controls">
				  <input type="password" name="password" class="span3"  id="password" placeholder="Password">
				</div>
			  </div>
			  <div class="control-group">
				<div class="controls">
				  <button type="submit" class="btn">Sign in</button> <a href="forgetpass.html">Forget password?</a>
				</div>
			  </div>
			</form>
		</div>
		</div>
	</div>	
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\user\userForgotPassword.blade.php ENDPATH**/ ?>