<div  id="footerSection">
	<div class="container">
		<div class="row">
			<div class="span3">
				<h5>ACCOUNT</h5>
				<a href="<?php echo e(url('/account')); ?>">YOUR ACCOUNT</a>
				<a href="#">PERSONAL INFORMATION</a>
				<?php if(Auth::check()): ?>
				<a href="<?php echo e(url('orders')); ?>">ORDER HISTORY</a>
				<?php endif; ?>
			</div>
			<div class="span3">
				<h5>INFORMATION</h5>
				<a href="<?php echo e(url('contact')); ?>">CONTACT</a>
				<a href="<?php echo e(url('about')); ?>">ABOUT US</a>
				<a href="<?php echo e(url('terms_and_condition')); ?>">TERMS AND CONDITIONS</a>
				<a href="<?php echo e(url('faq')); ?>">FAQ</a>
			</div>
			<div class="span3">
				<h5>OUR OFFERS</h5>
				<a href="#">NEW PRODUCTS</a>
				<a href="#">TOP SELLERS</a>
				<a href="#">SPECIAL OFFERS</a>
			</div>
			<div id="socialMedia" class="span3 pull-right">
				<h5>SOCIAL MEDIA </h5>
				<a href="#"><img width="60" height="60" src="<?php echo e(asset('front/images/facebook.png')); ?>" title="facebook" alt="facebook"/></a>
				<a href="#"><img width="60" height="60" src="<?php echo e(asset('front/images/twitter.png')); ?>" title="twitter" alt="twitter"/></a>
				<a href="#"><img width="60" height="60" src="<?php echo e(asset('front/images/youtube.png')); ?>" title="youtube" alt="youtube"/></a>
			</div>
		</div>
		<p class="pull-right"><a target="_blank" href="<?php echo e(url('https://everywearbd.com/')); ?>">&copy; Everywearbd</a></p>
	</div><!-- Container End -->
</div><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\layouts\front_layouts\front_footer.blade.php ENDPATH**/ ?>