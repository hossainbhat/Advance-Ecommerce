
<?php $__env->startSection('title','Place Order'); ?>
<?php $__env->startSection("content"); ?>
<div class="span9">
  <ul class="breadcrumb">
  <li><a href="index.html">Home</a> <span class="divider">/</span></li>
  <li class="active"> Thanks</li>
  </ul>
<h3>Thanks </h3>
<hr class="soft"/>
    <div style="align:center;">
        <h3>Your Order Has Been Placed Successfully</h3>
        <p>Your Order Number is <?php echo e(Session::get('order_id')); ?> and Grand Totanl is Taka <?php echo e(Session::get('grand_total')); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php
 Session::forget('grand_total');
 Session::forget('couponAmount');
 Session::forget('couponCode');
 Session::forget('order_id');
 ?>
<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\products\thanks.blade.php ENDPATH**/ ?>