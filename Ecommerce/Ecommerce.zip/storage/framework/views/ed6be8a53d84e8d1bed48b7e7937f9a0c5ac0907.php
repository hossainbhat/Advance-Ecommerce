
<?php $__env->startSection('title','Banner List'); ?>
<?php $__env->startSection('script_css'); ?>
<link href="<?php echo e(asset('backEnd/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<h6 class="mb-0 text-uppercase">Cms Page List</h6>
				<a style="float: right; margin-top: -30px;" href="<?php echo e(url('admin/add-edit-cms')); ?>"><button type="button" class="btn btn-success btn-sm"> Create Cms Page<i class="lni lni-circle-plus"></i></button></a>
				<hr/>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
						  <?php if(Session::has('success_message')): ?>
							<div class="alert alert-success border-0 bg-success alert-dismissible fade show">
								<div class="text-white"><?php echo e(Session::get('success_message')); ?></div>
								<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
							</div>
						  <?php endif; ?>
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
                                        <th width="10%">SL#</th>
                                        <th>Title</th>
                                        <th>Url</th>
                                        <th>Created At</th>
										<th width="10%">Modify</th>
									</tr>
								</thead>
								<tbody>
                                    <?php $__currentLoopData = $cmsPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($cms['title']); ?></td>
                                        <td><?php echo e($cms['url']); ?></td>
                                        <td><?php echo e(date('d-M-Y', strtotime($cms['created_at']))); ?></td>
                                        <td>
                                            <?php if($cms['status'] ==1): ?>
												<a class="updateCmsStatus" id="cms-<?php echo e($cms['id']); ?>" cms_id="<?php echo e($cms['id']); ?>" href="javascript:void(0)">Active</a>  
											<?php else: ?>
												<a class="updateCmsStatus" id="cms-<?php echo e($cms['id']); ?>" cms_id="<?php echo e($cms['id']); ?>" href="javascript:void(0)">Inactive</a>  
											<?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('admin/add-edit-cms/'.$cms['id'])); ?>"><button type="button" class="btn btn-success btn-sm"><i class="fadeIn animated bx bx-edit"></i></button></a>  

                                            <a class="confirmDelete btn btn-danger btn-sm" record="cms" recoedid="<?php echo e($cms['id']); ?>" href="javascript:void('0')" style="font-size: 16px;"><i class="fadeIn animated bx bx-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		<!--end page wrapper -->
		
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script_js"); ?>
<script src="<?php echo e(asset('backEnd/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\cms\cms_pages.blade.php ENDPATH**/ ?>