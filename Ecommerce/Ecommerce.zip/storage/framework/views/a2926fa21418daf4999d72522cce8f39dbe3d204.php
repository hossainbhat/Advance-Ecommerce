
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection("content"); ?>
<div class="page-wrapper">
	<div class="page-content">
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>