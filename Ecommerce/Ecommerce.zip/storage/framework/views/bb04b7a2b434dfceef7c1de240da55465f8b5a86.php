<?php
	use App\Models\Section;
	$sections = Section::sections();
	// echo "<pre>"; print_r($sections); die;
 ?>

<div id="header">
	<div class="container">
		<div id="welcomeLine" class="row">
			<div class="span6">Welcome! <?php if(Auth::check()): ?><strong> <?php echo e(Auth::user()->name); ?></strong><?php endif; ?></div>
			<div class="span6">
				<div class="pull-right">
					<a href="<?php echo e(url('cart')); ?>"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> [ <span class="totalCartItems"><?php echo e(totalCartItems()); ?></span>  ] Items in your cart </span> </a>
					<?php if(Auth::check()): ?>
					<a href="<?php echo e(url('wishlist-item')); ?>"><span class="btn btn-mini btn-primary"><i class="icon-heart-empty icon-white"></i> [ <span class="totalWishlisttems"><?php echo e(totalWishlisttems()); ?></span>  ] Wishlist </span> </a>
					<?php endif; ?> 
				</div>
			</div>
		</div>
		<!-- Navbar ================================================== -->
		<section id="navbar">
		  <div class="navbar">
		    <div class="navbar-inner">
		      <div class="container">
		        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
		          <span class="icon-bar"></span>
		          <span class="icon-bar"></span>
		          <span class="icon-bar"></span>
		        </a>
		        <a class="brand" href="<?php echo e(url('/')); ?>">Everywearbd</a>
		        <div class="nav-collapse">
		          <ul class="nav">
		            <li class="active"><a href="#">Home</a></li>
		            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            	<?php if(count($section['categories']) > 0): ?>
			            <li class="dropdown">
			              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($section->name); ?> <b class="caret"></b></a>
			              <ul class="dropdown-menu">
			              	<?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			              	<li class="divider"></li>
			                <li class="nav-header"><a href="<?php echo e($category['url']); ?>"><?php echo e($category->name); ?></a></li>
			                   <?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                     <li><a href="<?php echo e($subcategorie['url']); ?>"><?php echo e($subcategorie->name); ?></a></li>
			                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			              </ul>
			            </li>
			            <?php endif; ?>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		           
					
		          </ul>
		          <form class="navbar-search pull-left" action="<?php echo e(url('search-products')); ?>" method="get">
		            <input type="text" name="search" class="search-query span2" placeholder="Search"/>
					<button type="submit">Go</button>
		          </form>
		          <ul class="nav pull-right">
				  <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
				  <li class="divider-vertical"></li>
					<?php if(Auth::check()): ?>
						<li><a href="<?php echo e(url('/account')); ?>">My Account</a></li>
						<li><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
					<?php else: ?>
		            <li><a href="<?php echo e(url('login-register')); ?>">Login / Registation</a></li>
					<?php endif; ?>
		          </ul>
		        </div><!-- /.nav-collapse -->
		      </div>
		    </div><!-- /navbar-inner -->
		  </div><!-- /navbar -->
		</section>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\layouts\front_layouts\front_header.blade.php ENDPATH**/ ?>