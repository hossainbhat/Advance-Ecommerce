

<?php $__env->startSection('title',$cmsPageDetails['title']); ?>
<?php $__env->startSection("content"); ?>
<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active"><?php echo e($cmsPageDetails['title']); ?></li>
    </ul>
	<h3> <?php echo e($cmsPageDetails['title']); ?></h3>	
	<p>
	<?php echo nl2br($cmsPageDetails['description']); ?>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\pages\cms_page.blade.php ENDPATH**/ ?>