<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
    .invoice-title h2, .invoice-title h3 {
    display: inline-block;
}

.table > tbody > tr > .no-line {
    border-top: none;
}

.table > thead > tr > .no-line {
    border-bottom: none;
}

.table > tbody > tr > .thick-line {
    border-top: 2px solid;
}

</style>
<div class="container">
    <div class="row">
        <div class="col-xs-12">
    		<div class="invoice-title">
    			<h2>Invoice</h2><h3 class="pull-right">Order # <?php echo e($orderDetails['id']); ?></h3>
                <br>
                <span style="float:right;">
                    <?php echo DNS1D::getBarcodeHTML($orderDetails['id'], 'C39'); ?>
                </span>
                <br>
    		</div>
    		<hr>
    		<div class="row">
    			<div class="col-xs-6">
    				<address>
    				<strong>Billed To:</strong><br>
    					<?php echo e($userDetails['name']); ?><br>
    					<?php echo e($userDetails['address']); ?><br>
    					<?php echo e($userDetails['city']); ?><br>
    					<?php echo e($userDetails['state']); ?><br>
    					<?php echo e($userDetails['country']); ?><br>
    					<?php echo e($userDetails['pincode']); ?><br>
    					<?php echo e($userDetails['mobile']); ?><br>
    				</address>
    			</div>
    			<div class="col-xs-6 text-right">
    				<address>
        			<strong>Shipped To:</strong><br>
                        <?php echo e($orderDetails['name']); ?><br>
                        <?php if(!empty($orderDetails['address'])): ?>
    					<?php echo e($orderDetails['address']); ?>,
                        <?php endif; ?> 
                        <?php if(!empty($orderDetails['city'])): ?>
    					<?php echo e($orderDetails['city']); ?>, 
                        <?php endif; ?> 
                        <?php if(!empty($orderDetails['state'])): ?>
                        <?php echo e($orderDetails['state']); ?>, 
                        <?php endif; ?> 
                        <?php if(!empty($orderDetails['country'])): ?>
    					<?php echo e($orderDetails['country']); ?>,
                        <?php endif; ?> 
                        <?php if(!empty($orderDetails['pincode'])): ?>
                         <?php echo e($orderDetails['pincode']); ?> <br>
                        <?php endif; ?> 
                        <?php if(!empty($orderDetails['mobile'])): ?>
    					<?php echo e($orderDetails['mobile']); ?>

                        <?php endif; ?> <br>
    				</address>
    			</div>
    		</div>
    		<div class="row">
    			<div class="col-xs-6">
    				<address>
    					<strong>Payment Method:</strong><br>
    					<?php echo e($orderDetails['payment_method']); ?><br><br>
    				</address>
    			</div>
    			<div class="col-xs-6 text-right">
    				<address>
    					<strong>Order Date:</strong><br>
    					<?php echo e(date('d-M-Y', strtotime($orderDetails['created_at']))); ?>

    				</address>
    			</div>
    		</div>
    	</div>
    </div>
    
    <div class="row">
    	<div class="col-md-12">
    		<div class="panel panel-default">
    			<div class="panel-heading">
    				<h3 class="panel-title"><strong>Order summary</strong></h3>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    					<table class="table table-condensed">
    						<thead>
                                <tr>
        							<td><strong>Item</strong></td>
        							<td class="text-center"><strong>Price</strong></td>
        							<td class="text-center"><strong>Quantity</strong></td>
        							<td class="text-right"><strong>Total</strong></td>
                                </tr>
    						</thead>
    						<tbody>
                                <?php $tub_total= 0; ?>
                            <?php $__currentLoopData = $orderDetails['orders_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    							<tr>
    								<td>
                                        Name :<?php echo e($product['product_name']); ?> <br>
                                        Code :<?php echo e($product['product_code']); ?> <br>
                                        Size :<?php echo e($product['product_size']); ?> <br>
                                        Color :<?php echo e($product['product_color']); ?> <br>
										<?php echo DNS1D::getBarcodeHTML($product['product_code'], 'C39'); ?>
                                    </td>
    								<td class="text-center">Tk. <?php echo e($product['product_price']); ?></td>
    								<td class="text-center"><?php echo e($product['product_qty']); ?></td>
    								<td class="text-right">Tk. <?php echo e($product['product_price'] * $product['product_qty']); ?></td>
    							</tr>
                                <?php $tub_total= $tub_total + ($product['product_price'] * $product['product_qty']) ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                             
    							<tr>
    								<td class="thick-line"></td>
    								<td class="thick-line"></td>
    								<td class="thick-line text-center"><strong>Subtotal</strong></td>
    								<td class="thick-line text-right">Tk. <?php echo e($tub_total); ?></td>
    							</tr>
    							<tr>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-center"><strong>Shipping</strong></td>
    								<td class="no-line text-right">Tk.<?php echo e($orderDetails['shipping_charge']); ?></td>
    							</tr>
                                <?php if($orderDetails['coupon_amount'] >0): ?>
                                <tr>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-center"><strong>Discount</strong></td>
    								<td class="no-line text-right">Tk. <?php echo e($orderDetails['coupon_amount']); ?></td>
    							</tr>
                                <?php endif; ?> 
    							<tr>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-center"><strong>Grand Total</strong></td>
    								<td class="no-line text-right">Tk. <?php echo e($orderDetails['grand_total']); ?></td>
    							</tr>
    						</tbody>
    					</table>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\orders\order_invoice.blade.php ENDPATH**/ ?>