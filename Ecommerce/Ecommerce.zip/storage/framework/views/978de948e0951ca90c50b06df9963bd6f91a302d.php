
<?php $__env->startSection('title',$name); ?>
<?php $__env->startSection('script_css'); ?>
<link href="<?php echo e(asset('backEnd/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('backEnd/plugins/select2/css/select2-bootstrap4.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase"><?php echo e($name); ?></h6>                        
						<a href="<?php echo e(url('admin/brands')); ?>" style="float:right; margin-top:-30px;"><button class="btn btn-sm btn-success">Brand List <i class="lni lni-list"></i></button></a>

						<hr>
						<div class="card">
							<div class="card-body">
								<div class="p-4 border rounded">
										<?php if(Session::has('error_message')): ?>
											<div class="alert alert-danger border-0 bg-success alert-dismissible fade show">
												<div class="text-white"><?php echo e(Session::get('error_message')); ?></div>
												<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											</div>
										<?php endif; ?>
										<?php if($errors->any()): ?>
											<div class="alert alert-danger">
												<ul>
													<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li><?php echo e($error); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</div>
										<?php endif; ?>
									<form class="row g-3 needs-validation" <?php if(empty($categorydata['id'])): ?> action="<?php echo e(url('admin/add-edit-category')); ?>" <?php else: ?>   action="<?php echo e(url('admin/add-edit-category/'.$categorydata['id'] )); ?>" <?php endif; ?> method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                        <div class="col-md-9">
                                            <div class="mb-3" data-select2-id="21">
										        <label class="form-label">Section Name</label>
                                                <select name="section_id" id="section_id" class="section-select select2-hidden-accessible" data-select2-id="3" tabindex="-3" aria-hidden="true">
                                                <option value="0">Select</option>
                                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($section->id); ?>" <?php if(!empty($categorydata['section_id']) && $categorydata['section_id'] == $section->id ): ?> selected <?php endif; ?> > <?php echo e($section->name); ?> </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
								            </div>
                                        </div>
										<div class="col-md-9">
											<label for="name" class="form-label">Category name</label>
											<input type="text" name="name" class="form-control" id="name" placeholder="Enter category name" <?php if(!empty($categorydata['name'])): ?> value="<?php echo e($categorydata['name']); ?>" <?php else: ?> value="<?php echo e(old('name')); ?>" <?php endif; ?>>
										</div>
                                        <div id="appendCategoriesLevel" class="col-md-9">
                                            <?php echo $__env->make("admin.category.append_categories", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                        <div class="col-md-9">
											<label for="discount" class="form-label">Category Discount</label>
											<input type="text" name="discount" class="form-control" id="discount" placeholder="Enter category discount" <?php if(!empty($categorydata['discount'])): ?> value="<?php echo e($categorydata['discount']); ?>" <?php else: ?> value="<?php echo e(old('discount')); ?>" <?php endif; ?>>
										</div>
                                        
                                        <div class="col-md-9">
											<label for="url" class="form-label">Category Url</label>
											<input type="text" name="url" class="form-control" id="url" placeholder="Enter url" <?php if(!empty($categorydata['url'])): ?> value="<?php echo e($categorydata['url']); ?>" <?php else: ?> value="<?php echo e(old('url')); ?>" <?php endif; ?>>
										</div>
                                    <div class="col-9">
										<label for="description" class="form-label">Category Description</label>
										<textarea class="form-control" name="description" id="editor" placeholder="description..." rows="3"><?php if(!empty($categorydata['description'])): ?> <?php echo e($categorydata['description']); ?> <?php else: ?> <?php echo e(old('description')); ?> <?php endif; ?></textarea>
									</div>
                                    <div class="col-9">
										<label for="meta_title" class="form-label">Meta Title</label>
										<input type="text" name="meta_title" class="form-control" id="meta_title" placeholder="Enter meta_title" <?php if(!empty($categorydata['meta_title'])): ?> value="<?php echo e($categorydata['meta_title']); ?>" <?php else: ?> value="<?php echo e(old('meta_title')); ?>" <?php endif; ?>>
									</div>
                                    <div class="col-9">
										<label for="meta_description" class="form-label">Meta Description</label>
										<textarea class="form-control" name="meta_description" id="editor2" placeholder="meta_description..." rows="3"><?php if(!empty($categorydata['meta_description'])): ?> <?php echo e($categorydata['meta_description']); ?> <?php else: ?> <?php echo e(old('meta_description')); ?> <?php endif; ?></textarea>
									</div>
                                    <div class="col-9">
										<label for="meta_keywords" class="form-label">Meta Keywords</label>
										<input type="text" name="meta_keywords" class="form-control" id="meta_keywords" placeholder="Enter meta_keywords" <?php if(!empty($categorydata['meta_keywords'])): ?> value="<?php echo e($categorydata['meta_keywords']); ?>" <?php else: ?> value="<?php echo e(old('meta_keywords')); ?>" <?php endif; ?>>
									</div>
                                        <div class="row mb-3">
											<div class="col-sm-9 text-secondary">
                                                <label for="formFile" class="form-label">Category Image</label>
                                                <input class="form-control" name="image" type="file" id="formFile">
											</div>
                                            <?php if(!empty($categorydata['image'])): ?>
                                            <div style="height: 90px;">
                                                <img style="width: 80px; margin-top: 5px;" src="<?php echo e(asset('backEnd/images/category_image/'.$categorydata['image'])); ?>" >
                                                &nbsp;
	                    		                <a class="confirmDelete" record="category-image" recoedid="<?php echo e($categorydata['id']); ?>" href="javascript:void('0')">Delete</a>
                                            </div>
                                       		 <?php endif; ?>
										</div>
										<div class="col-12">
											<button class="btn btn-primary" type="submit"><?php echo e($name); ?></button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--end row-->
			</div>
		</div>	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_js'); ?>
<script src="<?php echo e(asset('backEnd/plugins/select2/js/select2.min.js')); ?>"></script>
<script>
		$('.section-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
        $('.appendcategory-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
	</script>
	
<script src="https://cdn.ckeditor.com/ckeditor5/34.1.0/classic/ckeditor.js"></script>

<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        } );
		ClassicEditor
        .create( document.querySelector( '#editor2' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\category\add_edit_category.blade.php ENDPATH**/ ?>