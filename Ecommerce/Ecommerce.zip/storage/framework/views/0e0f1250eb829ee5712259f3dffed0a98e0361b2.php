<footer class="page-footer">
	<p class="mb-0">Copyright © <?php echo date('Y'); ?>. All right reserved.</p>
</footer><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\layouts\admin_layouts\admin_footer.blade.php ENDPATH**/ ?>