
<?php $__env->startSection('title',$name); ?>
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase"><?php echo e($name); ?></h6>                        
						<a href="<?php echo e(url('admin/brands')); ?>" style="float:right; margin-top:-30px;"><button class="btn btn-sm btn-success">Brand List <i class="lni lni-list"></i></button></a>

						<hr>
						<div class="card">
							<div class="card-body">
								<div class="p-4 border rounded">
										<?php if(Session::has('error_message')): ?>
											<div class="alert alert-danger border-0 bg-success alert-dismissible fade show">
												<div class="text-white"><?php echo e(Session::get('error_message')); ?></div>
												<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											</div>
										<?php endif; ?>
										<?php if($errors->any()): ?>
											<div class="alert alert-danger">
												<ul>
													<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li><?php echo e($error); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</div>
										<?php endif; ?>
									<form class="row g-3 needs-validation" <?php if(empty($bannerdata['id'])): ?> action="<?php echo e(url('admin/add-edit-banner')); ?>" <?php else: ?>   action="<?php echo e(url('admin/add-edit-banner/'.$bannerdata['id'] )); ?>" <?php endif; ?> method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    
										<div class="col-md-9">
											<label for="link" class="form-label">link</label>
											<input type="text" name="link" class="form-control" id="link" placeholder="Enter link" <?php if(!empty($bannerdata['link'])): ?> value="<?php echo e($bannerdata['link']); ?>" <?php else: ?> value="<?php echo e(old('link')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-md-9">
											<label for="title" class="form-label">title</label>
											<input type="text" name="title" class="form-control" id="title" placeholder="Enter title" <?php if(!empty($bannerdata['title'])): ?> value="<?php echo e($bannerdata['title']); ?>" <?php else: ?> value="<?php echo e(old('title')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-md-9">
											<label for="alt" class="form-label">alt</label>
											<input type="text" name="alt" class="form-control" id="alt" placeholder="Enter alt" <?php if(!empty($bannerdata['alt'])): ?> value="<?php echo e($bannerdata['alt']); ?>" <?php else: ?> value="<?php echo e(old('alt')); ?>" <?php endif; ?>>
										</div>
										<div class="row mb-3">
											<div class="col-sm-9 text-secondary">
                                                <label for="formFile" class="form-label">Banner Image</label>
                                                <input class="form-control" name="image" type="file" id="formFile">
											</div>
                                            <?php if(!empty($bannerdata['image'])): ?>
                                            <div style="height: 90px;">
                                                <img style="width: 80px; margin-top: 5px;" src="<?php echo e(asset('backEnd/images/banners/'.$bannerdata['image'])); ?>" >
                                                &nbsp;
	                    		                <a class="confirmDelete" record="banner-image" recoedid="<?php echo e($bannerdata['id']); ?>" href="javascript:void('0')">Delete</a>
                                            </div>
                                       		 <?php endif; ?>
										</div>
										<div class="col-12">
											<button class="btn btn-primary" type="submit"><?php echo e($name); ?></button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--end row-->
			</div>
		</div>	
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\banner\add_edit_banner.blade.php ENDPATH**/ ?>