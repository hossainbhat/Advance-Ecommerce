
<?php use App\Models\Product; ?>

<?php $__env->startSection('title','Orders Details'); ?>
<?php $__env->startSection('script_css'); ?>
<link href="<?php echo e(asset('backEnd/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="page-wrapper">
			<div class="page-content">
			<h6 class="mb-0 text-uppercase">Order #<?php echo e($orderDetails['id']); ?> Details</h6>
						<hr>
				<!--end breadcrumb-->
                <?php if(Session::has('success_message')): ?>
							<div class="alert alert-success border-0 bg-success alert-dismissible fade show">
								<div class="text-white"><?php echo e(Session::get('success_message')); ?></div>
								<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
							</div>
						  <?php endif; ?>
				<div class="row">
					<div class="col-xl-6 mx-auto">
					
						<div class="card">
							<div class="card-body">
								<table class="table table-bordered mb-0">
									
									<tbody>
                                        <tr>
                                            <td colspan="2"><strong>Order Details</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Order Date</td>
                                            <td><?php echo e(date('d-M-Y', strtotime($orderDetails['created_at']))); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Order Status</td>
                                            <td><?php echo e($orderDetails['order_status']); ?></td>
                                        </tr>
                                        <?php if(!empty($orderDetails['courier_name'])): ?>
                                        <tr>
                                            <td>Courier Name</td>
                                            <td><?php echo e($orderDetails['courier_name']); ?></td>
                                        </tr>
                                        <?php endif; ?> 
                                        <?php if(!empty($orderDetails['traking_number'])): ?>
                                        <tr>
                                            <td>Traking Number</td>
                                            <td><?php echo e($orderDetails['traking_number']); ?></td>
                                        </tr>
                                        <?php endif; ?> 
                                        <tr>
                                            <td>Order Total</td>
                                            <td><?php echo e($orderDetails['grand_total']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Shipping Charge</td>
                                            <td><?php echo e($orderDetails['shipping_charge']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Cupon Code</td>
                                            <td><?php echo e($orderDetails['coupon_code']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Coupon Amount</td>
                                            <td><?php echo e($orderDetails['coupon_amount']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Payment Method</td>
                                            <td><?php echo e($orderDetails['payment_method']); ?></td>
                                        </tr>

									</tbody>
								</table>
							</div>
						</div>


                        
					</div>
                    <div class="col-xl-6 mx-auto">
					
						<div class="card">
							<div class="card-body">
								<table class="table table-bordered mb-0">
									
									<tbody>

                                         <tr>
                                            <td colspan="2"><strong>Delivary Address</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Name</td>
                                            <td><?php echo e($orderDetails['name']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Address</td>
                                            <td><?php echo e($orderDetails['address']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>City</td>
                                            <td><?php echo e($orderDetails['city']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>State</td>
                                            <td><?php echo e($orderDetails['state']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Country</td>
                                            <td><?php echo e($orderDetails['country']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Pincode</td>
                                            <td><?php echo e($orderDetails['pincode']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Mobile</td>
                                            <td><?php echo e($orderDetails['mobile']); ?></td>
                                        </tr>

									</tbody>
								</table>
							</div>
						</div>


                        
					</div>
                    
                    <div class="col-xl-6 mx-auto">
					
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered mb-0">
                               
                                <tbody>

                                        <tr>
                                            <td colspan="2"><strong>Billing Address</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Name</td>
                                            <td><?php echo e($userDetails['name']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Address</td>
                                            <td><?php echo e($userDetails['address']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>City</td>
                                            <td><?php echo e($userDetails['city']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Mobile</td>
                                            <td><?php echo e($userDetails['mobile']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Pincode</td>
                                            <td><?php echo e($userDetails['pincode']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>State</td>
                                            <td><?php echo e($userDetails['state']); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Country</td>
                                            <td><?php echo e($userDetails['country']); ?></td>
                                        </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>


                    
                </div>
                <div class="col-xl-6 mx-auto">
						<div class="card">
							<div class="card-body">
								<table class="table table-bordered mb-0">
                               
                                            <tr>
                                                <td colspan="2"><strong>Update Order Status</strong></td>
                                            </tr>
                                        <form action="<?php echo e(url('admin/update-order-status')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                                <input type="hidden" name="order_id" value="<?php echo e($orderDetails['id']); ?>">
                                                <tr>
                                                    <td>
                                                    
                                                        <select name="order_status" id="order_status" required="" class="form-select form-select-sm mb-3" aria-label=".form-select-sm example">
                                                            <option selected="">Select Status</option>
                                                            <?php $__currentLoopData = $orderStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($status['name']); ?>" <?php if($orderDetails['order_status'] && $orderDetails['order_status'] == $status['name']): ?> selected="" <?php endif; ?>><?php echo e($status['name']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    
                                                    <td <?php if(empty($orderDetails['courier_name'])): ?> id="courier_name" <?php endif; ?>><input style="width:120px;" type="text" name="courier_name" placeholder="Courier Name" value="<?php echo e($orderDetails['courier_name']); ?>"></td>
                                                    <td <?php if(empty($orderDetails['traking_number'])): ?> id="traking_number" <?php endif; ?>> <input style="width:120px;" type="text" name="traking_number" placeholder="Traking Number" value="<?php echo e($orderDetails['traking_number']); ?>"></td>

                                                    <td><input type="submit" value="Update" class="btn btn-success btn-sm"></td>
                                                </tr>
                                                <tr>
                                                    <td  colspan="4">
                                                        <?php $__currentLoopData = $orderLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <strong><?php echo e($log['order_status']); ?></strong> <br><?php echo e(date('d-M-Y g:i:sa', strtotime($log['created_at']))); ?> <hr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                </tr>
                                        </form>
								</table>
							</div>
						</div>


                        
					</div>
                    <div class="col-xl-12 mx-auto">
					
						<div class="card">
							<div class="card-body">
								<table class="table table-bordered mb-0">
									<thead>
										<tr>
                                            <td>Product Image</td>
                                            <td>Product Code</td>
                                            <td>Product Name</td>
                                            <td>Product size</td>
                                            <td>Product Color</td>
                                            <td>Product Qty</td>
										</tr>
									</thead>
									<tbody>

                                        <?php $__currentLoopData = $orderDetails['orders_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php $getProductImage = Product::getProductImage($product['product_id']) ?>
                                                    <a href="<?php echo e(url($product['product_id'])); ?>"><img style="width:80px;height:90px;" src="<?php echo e(asset('backEnd/images/products/small/'.$getProductImage)); ?>" alt=""></a>
                                                </td>
                                                <td><?php echo e($product['product_code']); ?></td>
                                                <td><?php echo e($product['product_name']); ?></td>
                                                <td><?php echo e($product['product_size']); ?></td>
                                                <td><?php echo e($product['product_color']); ?></td>
                                                <td><?php echo e($product['product_qty']); ?></td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</tbody>
								</table>
							</div>
						</div>


                        
					</div>
                   
                    
				</div>
				<!--end row-->
			</div>
		</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script_js"); ?>
<script src="<?php echo e(asset('backEnd/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\orders\order_details.blade.php ENDPATH**/ ?>