
<?php $__env->startSection('title','User Account'); ?>
<?php $__env->startSection('front_css'); ?>
<style>
form.cmxform label.error, label.error {
    color: red;
    font-style: italic;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="span9">
    <ul class="breadcrumb">
		<li><a href="<?php echo e(url('/')); ?>">Home</a> <span class="divider">/</span></li>
		<li><a href="<?php echo e(url('/account')); ?>">My Account</a> <span class="divider">/</span></li>
		<li><a href="<?php echo e(url('/orders')); ?>">My Order</a></li>
    </ul>
	<h3> My Account</h3>	
	<hr class="soft"/>
	
	<div class="row">
	<?php if(Session::has('success_message')): ?>
     <div class="alert alert-success" role="alert">
       <?php echo e(Session::get('success_message')); ?>

       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>
     <?php endif; ?>
	<?php if(Session::has('error_message')): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e(Session::get('error_message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>
    <?php endif; ?>
		<div class="span4">
			<div class="well">
			<h5>Contact Details</h5><br/>
			User Account details.<br/><br/><br/>
			<form id="userAccountForm" action="<?php echo e(url('account')); ?>" method="post">
				<?php echo csrf_field(); ?>
			  <div class="control-group">
				<label class="control-label" for="name"> Name</label>
				<div class="controls">
				  <input class="span3" name="name"  type="text" id="name" value="<?php echo e($userDetails['name']); ?>" placeholder="Enter Name" required pattern="[A-Za-z]+">
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="address"> Address</label>
				<div class="controls">
				  <input class="span3" name="address"  type="text" id="address" value="<?php echo e(@$userDetails['address']); ?>" placeholder="Enter address">
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="city"> City</label>
				<div class="controls">
				  <input class="span3" name="city"  type="text" id="city" value="<?php echo e(@$userDetails['city']); ?>" placeholder="Enter city">
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="state"> State</label>
				<div class="controls">
				  <input class="span3" name="state"  type="text" id="state" value="<?php echo e(@$userDetails['state']); ?>" placeholder="Enter state">
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="country"> Country</label>
				<div class="controls">
				  
					<select class="span3" name="country" id="country">
						<option value="">select country</option>
						<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($country->country_name); ?>" <?php if($country->country_name == $userDetails['country']): ?> selected="" <?php endif; ?>><?php echo e($country->country_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="pincode"> Pincode</label>
				<div class="controls">
				  <input class="span3" name="pincode"  type="text" id="pincode" value="<?php echo e(@$userDetails['pincode']); ?>" placeholder="Enter pincode">
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="mobile">Mobile</label>
				<div class="controls">
				  <input class="span3" name="mobile"  type="text" id="mobile" value="<?php echo e(@$userDetails['mobile']); ?>" placeholder="Enter Mobile">
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="email">E-mail</label>
				<div class="controls">
				  <input class="span3" type="text" readonly value="<?php echo e(@$userDetails['email']); ?>">
				</div>
			  </div>
             
			  <div class="controls">
			  <button type="submit" class="btn block">Update</button>
			  </div>
			</form>
		</div>
		</div>
		<div class="span1"> &nbsp;</div>
		<div class="span4">
			<div class="well">
			<h5>Update Password</h5>
			<form id="LoginForm" action="<?php echo e(url('update-user-pwd')); ?>" method="post">
				<?php echo csrf_field(); ?>
			 
			  <div class="control-group">
				<label class="control-label" for="current_pwd">Current Password</label>
				<div class="controls">
				  <input type="password" name="current_pwd" class="span3"  id="current_pwd" placeholder="Password">
				  <br><span id="chkPwd"></span>
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="new_pwd">New Password</label>
				<div class="controls">
				  <input type="password" name="new_pwd" class="span3"  id="new_pwd" placeholder="Password">
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="confirm_pwd">Confirmm New Password</label>
				<div class="controls">
				  <input type="password" name="confirm_pwd" class="span3"  id="confirm_pwd" placeholder="Password">
				</div>
			  </div>
			  <div class="control-group">
				<div class="controls">
				  <button type="submit" class="btn">Update</button> 
				</div>
			  </div>
			</form>
		</div>
		</div>
	</div>	
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\user\user_account.blade.php ENDPATH**/ ?>