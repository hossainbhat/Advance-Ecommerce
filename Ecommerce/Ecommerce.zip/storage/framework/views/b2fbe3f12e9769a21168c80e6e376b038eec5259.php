
<?php $__env->startSection('title',$name); ?>
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase"><?php echo e($name); ?></h6>                        
						<a href="<?php echo e(url('admin/cms-pages')); ?>" style="float:right; margin-top:-30px;"><button class="btn btn-sm btn-success">Cms Page List <i class="lni lni-list"></i></button></a>

						<hr>
						<div class="card">
							<div class="card-body">
								<div class="p-4 border rounded">
										<?php if(Session::has('error_message')): ?>
											<div class="alert alert-danger border-0 bg-success alert-dismissible fade show">
												<div class="text-white"><?php echo e(Session::get('error_message')); ?></div>
												<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											</div>
										<?php endif; ?>
										<?php if($errors->any()): ?>
											<div class="alert alert-danger">
												<ul>
													<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li><?php echo e($error); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</div>
										<?php endif; ?>
									<form class="row g-3 needs-validation" <?php if(empty($cmsdata['id'])): ?> action="<?php echo e(url('admin/add-edit-cms')); ?>" <?php else: ?>   action="<?php echo e(url('admin/add-edit-cms/'.$cmsdata['id'] )); ?>" <?php endif; ?> method="post">
                                    <?php echo csrf_field(); ?>
                                    
										<div class="col-md-9">
											<label for="title" class="form-label">Title</label>
											<input type="text" name="title" class="form-control" id="title" placeholder="Enter title" <?php if(!empty($cmsdata['title'])): ?> value="<?php echo e($cmsdata['title']); ?>" <?php else: ?> value="<?php echo e(old('title')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-md-9">
											<label for="url" class="form-label">Url</label>
											<input type="text" name="url" class="form-control" id="url" placeholder="Enter url" <?php if(!empty($cmsdata['url'])): ?> value="<?php echo e($cmsdata['url']); ?>" <?php else: ?> value="<?php echo e(old('url')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-9">
										    <label for="description" class="form-label">Description</label>
                                            <textarea class="form-control" id="editor" name="description"  placeholder="description..." rows="3"><?php if(!empty($cmsdata['description'])): ?> <?php echo e($cmsdata['description']); ?> <?php else: ?> <?php echo e(old('description')); ?> <?php endif; ?></textarea>
                                        </div>
                                        <div class="col-md-9">
											<label for="meta_title" class="form-label">Meta Title</label>
											<input type="text" name="meta_title" class="form-control" id="meta_title" placeholder="Enter meta_title" <?php if(!empty($cmsdata['meta_title'])): ?> value="<?php echo e($cmsdata['meta_title']); ?>" <?php else: ?> value="<?php echo e(old('meta_title')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-9">
										    <label for="meta_description" class="form-label">Meta Description</label>
                                            <textarea class="form-control" name="meta_description" id="editor2" placeholder="description..." rows="3"><?php if(!empty($cmsdata['meta_description'])): ?> <?php echo e($cmsdata['meta_description']); ?> <?php else: ?> <?php echo e(old('meta_description')); ?> <?php endif; ?></textarea>
                                        </div>
										<div class="col-md-9">
											<label for="meta_keyword" class="form-label">Meta Keyword</label>
											<input type="text" name="meta_keyword" class="form-control" id="meta_keyword" placeholder="Enter meta_keyword" <?php if(!empty($cmsdata['meta_keyword'])): ?> value="<?php echo e($cmsdata['meta_keyword']); ?>" <?php else: ?> value="<?php echo e(old('meta_keyword')); ?>" <?php endif; ?>>
										</div>
                                       
										
										<div class="col-12">
											<button class="btn btn-primary" type="submit"><?php echo e($name); ?></button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--end row-->
			</div>
		</div>	
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script_js"); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/34.1.0/classic/ckeditor.js"></script>

<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        } );
		ClassicEditor
        .create( document.querySelector( '#editor2' ) )
        .catch( error => {
            console.error( error );
        } );
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\cms\add_edit_cms.blade.php ENDPATH**/ ?>