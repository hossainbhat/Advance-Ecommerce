<?php 
use App\Models\Product; 
?>

<?php $__env->startSection('title','Wishlist'); ?>
<?php $__env->startSection("content"); ?>
<div class="span9">
  <ul class="breadcrumb">
  <li><a href="index.html">Home</a> <span class="divider">/</span></li>
  <li class="active"> Wishlist</li>
  </ul>
    <h3>  Wishlist [ <small><span class="totalWishlisttems"><?php echo e((totalWishlisttems())); ?></span> Item(s) </small>]<a href="<?php echo e(url('/')); ?>" class="btn btn-large pull-right"><i class="icon-arrow-left"></i> Continue Shopping </a></h3>
    <hr class="soft"/>


    <div id="appentWishlistItems">
        <?php echo $__env->make('front.products.wishlist_item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <a href="<?php echo e(url('/')); ?>" class="btn btn-large"><i class="icon-arrow-left"></i> Continue Shopping </a>

</div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\products\wish_list.blade.php ENDPATH**/ ?>