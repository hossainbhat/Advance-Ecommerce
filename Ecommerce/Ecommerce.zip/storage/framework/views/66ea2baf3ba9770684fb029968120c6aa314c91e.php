

<?php $__env->startSection('title','Cart Item'); ?>
<?php $__env->startSection("content"); ?>
<div class="span9">
  <ul class="breadcrumb">
  <li><a href="index.html">Home</a> <span class="divider">/</span></li>
  <li class="active"> SHOPPING CART</li>
  </ul>
<h3>  SHOPPING CART [ <small> <span class="totalCartItems"><?php echo e(totalCartItems()); ?> </span> Item(s) </small>]<a href="<?php echo e(url('/')); ?>" class="btn btn-large pull-right"><i class="icon-arrow-left"></i> Continue Shopping </a></h3>
<hr class="soft"/>

<?php if(Session::has('success_message')): ?>
     <div class="alert alert-success" role="alert">
       <?php echo e(Session::get('success_message')); ?>

       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>
     <?php Session::forget('success_message') ?>
     <?php endif; ?>
     <?php if(Session::has('error_message')): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e(Session::get('error_message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php Session::forget('error_message') ?>
    <?php endif; ?>

    <div id="AppendCartItems">
      <?php echo $__env->make("front.products.cart_items", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


<a href="<?php echo e(url('/')); ?>" class="btn btn-large"><i class="icon-arrow-left"></i> Continue Shopping </a>
<a href="<?php echo e(url('/checkout')); ?>" class="btn btn-large pull-right">Next <i class="icon-arrow-right"></i></a>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\products\cart_view.blade.php ENDPATH**/ ?>