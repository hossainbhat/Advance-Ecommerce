

<div class="form-group">
	<label>Category lavel select</label>
	<select name="parent_id" id="parent_id" class="appendcategory-select form-control select2"  style="width: 100%;">
	<option value="0" <?php if(isset($categorydata['parent_id']) && $categorydata['parent_id']==0): ?> selected="" <?php endif; ?> >Main Category</option>
	<?php if(!empty($getCategories)): ?>
		<?php $__currentLoopData = $getCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($category['id']); ?>" <?php if(isset($categorydata['parent_id']) && $categorydata['parent_id'] == $category['id']): ?> selected="" <?php endif; ?>>&bull;<?php echo e($category['name']); ?></option>
			<?php if(!empty($category['subcategories'])): ?>
				<?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($subcategory['id']); ?>">&nbsp;&nbsp;&nbsp;&raquo;<?php echo e($subcategory['name']); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
	</select>
</div><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\category\append_categories.blade.php ENDPATH**/ ?>