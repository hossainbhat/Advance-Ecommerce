
<?php $__env->startSection('title','Shepping Charge List'); ?>
<?php $__env->startSection('script_css'); ?>
<link href="<?php echo e(asset('backEnd/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<h6 class="mb-0 text-uppercase">Shipping Charge List</h6>
				<hr/>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
						  <?php if(Session::has('success_message')): ?>
							<div class="alert alert-success border-0 bg-success alert-dismissible fade show">
								<div class="text-white"><?php echo e(Session::get('success_message')); ?></div>
								<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
							</div>
						  <?php endif; ?>
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th width="10%">SL#</th>
										<th>Country</th>
                                        <th>0 To 500g</th>
                                        <th>501g To 1000g</th>
                                        <th>1001g To 2000g</th>
                                        <th>2001g To 3000g</th>
                                        <th>3001g To 4000g</th>
                                        <th>above To 5000g</th>
										<th>Status</th>
										<th>Updated At</th>
										<th width="10%">Modify</th>
									</tr>
								</thead>
								<tbody>
								<?php $__currentLoopData = $shipping_charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
										<td><?php echo e($key+1); ?></td>
										<td><?php echo e($shipping['country']); ?></td>
                                        <td><?php echo e($shipping['0_500g']); ?></td>
                                        <td><?php echo e($shipping['501g_1000g']); ?></td>
                                        <td><?php echo e($shipping['1001g_2000g']); ?></td>
                                        <td><?php echo e($shipping['2001g_3000g']); ?></td>
                                        <td><?php echo e($shipping['3001g_4000g']); ?></td>
                                        <td><?php echo e($shipping['above_5000g']); ?></td>
										<td>
											<?php if($shipping['status'] ==1): ?>
												<a class="updateShippingChargeStatus" id="shipping-<?php echo e($shipping['id']); ?>" shipping_id="<?php echo e($shipping['id']); ?>" href="javascript:void(0)">Active</a>  
											<?php else: ?>
												<a class="updateShippingChargeStatus" id="shipping-<?php echo e($shipping['id']); ?>" shipping_id="<?php echo e($shipping['id']); ?>" href="javascript:void(0)">Inactive</a>  
											<?php endif; ?>
										</td>
                                        <td><?php echo e(date('d-M-Y', strtotime($shipping['updated_at']))); ?></td>
										<td>
											<a href="<?php echo e(url('admin/edit-shipping-charges/'.$shipping['id'])); ?>"><button type="button" class="btn btn-success btn-sm"><i class="fadeIn animated bx bx-edit"></i></button></a>  
									</tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								</tbody>
							</table>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		<!--end page wrapper -->
		
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script_js"); ?>
<script src="<?php echo e(asset('backEnd/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\shipping\view_shipping_charges.blade.php ENDPATH**/ ?>