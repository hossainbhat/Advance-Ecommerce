<!DOCTYPE html>
<body>
    <table style="width:700px;">
        <tr><td>&nbsp;</td></tr>
        <tr>
            <td><img src="<?php echo e(asset('front/images/logo_email.png')); ?>" alt=""></td>
        </tr>
        <tr><td>&nbsp;</td></tr>
        <tr><td>Hello <?php echo e($name); ?>,</td></tr>
        <tr><td>&nbsp;</td></tr>
        <tr><td>Your Order #<?php echo e($order_id); ?> status has been updated to <?php echo e($order_status); ?>. Your Order Details are as below:-</td></tr>
        <?php if(!empty($courier_name) && !empty($traking_number)): ?>
        <tr><td>&nbsp;</td></tr>
        <tr><td>Courier Name is <?php echo e($courier_name); ?> and Traking Number is #<?php echo e($traking_number); ?></td></tr>
        <?php endif; ?> 
        <tr><td>&nbsp;</td></tr>
        <tr><td>Order No: <?php echo e($order_id); ?></td></tr>
        <tr><td>&nbsp;</td></tr>
        <tr><td>
            <table style="width:95%" cellspacing="5" collspacing="5" bgcolor="#f7f4f4">
                <tr bgcolor="#cccccc">
                    <td>Product Name</td>
                    <td>Code</td>
                    <td>Size</td>
                    <td>Color</td>
                    <td>Quantity</td>
                    <td>Price</td>
                </tr>
                <?php $__currentLoopData = $orderDetails['orders_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order['product_name']); ?></td>
                    <td><?php echo e($order['product_code']); ?></td>
                    <td><?php echo e($order['product_size']); ?></td>
                    <td><?php echo e($order['product_color']); ?></td>
                    <td><?php echo e($order['product_qty']); ?></td>
                    <td><?php echo e($order['product_price']); ?> Tk</td>
                </tr>
                <tr>
                    <td colspan="5" align="right">Shipping Charges</td>
                    <td>Tk <?php echo e($orderDetails['shipping_charge']); ?></td>
                </tr>
                <tr>
                    <td colspan="5" align="right">Coupon Discount</td>
                    <td>Tk 
                    <?php if($orderDetails['coupon_amount'] >0): ?>    
                        <?php echo e($orderDetails['coupon_amount']); ?></td>
                    <?php else: ?> 
                        0
                    <?php endif; ?>
                </tr>
                <tr>
                    <td colspan="5" align"right">Grand Total</td>
                    <td>Tk <?php echo e($orderDetails['grand_total']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </td></tr>
        <tr><td>&nbsp;</td></tr>
        <tr><td>
            <table>
                <tr>
                    <td><strong>Delivery Address :</strong></td>
                </tr>
                <tr>
                    <td><?php echo e($orderDetails['name']); ?></td>
                </tr>
                <tr>
                    <td><?php echo e($orderDetails['address']); ?></td>
                </tr>
                <tr>
                    <td><?php echo e($orderDetails['city']); ?></td>
                </tr>
                <tr>
                    <td><?php echo e($orderDetails['state']); ?></td>
                </tr>
                <tr>
                    <td><?php echo e($orderDetails['country']); ?></td>
                </tr>
                <tr>
                    <td><?php echo e($orderDetails['pincode']); ?></td>
                </tr>
                <tr>
                    <td><?php echo e($orderDetails['mobile']); ?></td>
                </tr>
            </table>
            <tr><td>&nbsp;</td></tr>
            <tr><td>For Any enquiries, You can Contact Us at <a href="#">Online StoreBD.com</a></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Regards,<br> Team Online StoreBD</td></tr>
            <tr><td>&nbsp;</td></tr>
        </td></tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\emails\order_status.blade.php ENDPATH**/ ?>