
<?php $__env->startSection('title','Product Listing'); ?>
<?php $__env->startSection("content"); ?>
		<!-- Sidebar end=============================================== -->
		<div class="span9">
			<ul class="breadcrumb">
				<li><a href="<?php echo e(url('/')); ?>">Home</a> <span class="divider">/</span></li>
				<li class="active"><?php echo $categoryDetails['breadcrumbs']; ?></li>
			</ul>
			<h3> <?php echo e($categoryDetails['categoryDetails']['name']); ?> <small class="pull-right"><?php echo e(count($categoryProduct)); ?> products are available </small></h3>
			<hr class="soft"/>
			<p>
			 <?php echo e($categoryDetails['categoryDetails']['description']); ?>

			</p>
			<hr class="soft"/>
			<?php if(!isset($_REQUEST['search'])): ?>
			<form class="form-horizontal span6" name="sortProducts" id="sortProducts">
				<input type="hidden" name="url" id="url" value="<?php echo e($url); ?>">
				<div class="control-group">
					<label class="control-label alignL">Sort By </label>
					<select name="sort" id="sort">
						<option value="">Select</option>
						<option value="product_latest" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'product_latest'): ?> selected="" <?php endif; ?>>Latest Products</option>
						<option value="product_name_a_z" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'product_name_a_z'): ?> selected="" <?php endif; ?>>Product name A - Z</option>
						<option value="product_name_z_a" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'product_name_z_a'): ?> selected="" <?php endif; ?>>Product name Z - A</option>
						<option value="price_lowest" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'price_lowest'): ?> selected="" <?php endif; ?>> Lowest Price first</option>
						<option value="price_height" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'price_height'): ?> selected="" <?php endif; ?>>Height Price first</option>
					</select>
				</div>
			</form>
			<?php endif; ?> 
			<div id="myTab" class="pull-right">
				<a href="#blockView" data-toggle="tab"></a>
			</div>
			<br class="clr"/>
			<div class="tab-content filter_products">

				<?php echo $__env->make('front.products.ajax_products_listing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			</div>
			<a href="compair.html" class="btn btn-large pull-right">Compare Product</a>
			<?php if(!isset($_REQUEST['search'])): ?>
			<div class="pagination">
				<?php if(isset($_GET['sort']) && !empty($_GET['sort'])): ?>
					<?php echo e($categoryProduct->appends(['sort' => 'price_lowest'])->links()); ?>

				<?php else: ?>
				 	<?php echo e($categoryProduct->links()); ?>

				<?php endif; ?>
			</div>
			<?php endif; ?> 
			<br class="clr"/>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\products\listing.blade.php ENDPATH**/ ?>