
<?php $__env->startSection('title','Order'); ?>
<?php $__env->startSection('front_css'); ?>
<style>
form.cmxform label.error, label.error {
    color: red;
    font-style: italic;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="span9">
    <ul class="breadcrumb">
		<li><a href="<?php echo e(url('/')); ?>">Home</a> <span class="divider">/</span></li>
		<li class="active">Orders</li>
    </ul>
	<h3> Orders</h3>	
	<hr class="soft"/>
	
	    <div class="row">
	
            <div class="span8">
                <table class="table table-striped table-bordered">
                    <tr>
                        <td>Order Id</td>
                        <td>Order Product</td>
                        <td>Payment Method</td>
                        <td>Grend Total</td>
                        <td>Created On</td>
                        <td>Detaisls</td>
                    </tr>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order['id']); ?></td>
                        <td>
                            <?php $__currentLoopData = $order['orders_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($pro['product_code']); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($order['payment_method']); ?></td>
                        <td><?php echo e($order['grand_total']); ?> .Tk</td>
                        <td><?php echo e(date('d-M-Y', strtotime($order['created_at']))); ?></td>
                        <td><a style="text-decoration:underline" href="<?php echo e(url('orders/'.$order['id'])); ?>">View Details</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
		
	    </div>
	</div>	
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\orders\orders.blade.php ENDPATH**/ ?>