<?php 
use App\Models\Product; 
?>

<?php $__env->startSection('title','Checkout'); ?>
<?php $__env->startSection("content"); ?>
<div class="span9">
  <ul class="breadcrumb">
  <li><a href="index.html">Home</a> <span class="divider">/</span></li>
  <li class="active"> Checkout</li>
  </ul>
<h3>  Checkout [ <small> <span class="totalCartItems"><?php echo e(totalCartItems()); ?> </span> Item(s) </small>]<a href="<?php echo e(url('/cart')); ?>" class="btn btn-large pull-right"><i class="icon-arrow-left"></i> Back to Cart </a></h3>
<hr class="soft"/>

<?php if(Session::has('success_message')): ?>
     <div class="alert alert-success" role="alert">
       <?php echo e(Session::get('success_message')); ?>

       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>
     <?php Session::forget('success_message') ?>
     <?php endif; ?>
     <?php if(Session::has('error_message')): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e(Session::get('error_message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php Session::forget('error_message') ?>
    <?php endif; ?>

<form name="checkoutForm" id="checkoutForm" action="<?php echo e(url('checkout')); ?>" method="post">
  <?php echo csrf_field(); ?> 
  <table class="table table-bordered">
      <tbody><tr><th><strong>DELIVERY ADDRESSES</strong>  <a style="float:right;" href="<?php echo e(url('add-edit-dalivary-address')); ?>">Add</a>  </th></tr>
      <?php $__currentLoopData = $deliveryAddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <tr> 
              <td>
                  <div class="control-group" style="float:left; margin-right:5px; margin-top:-2px;">
                      <input type="radio" id="address<?php echo e($address->id); ?>" name="address_id" value="<?php echo e($address->id); ?>" shipping_charges="<?php echo e($address['shipping_charges']); ?>" total_price="<?php echo e($total_price); ?>" coupon_amount="<?php echo e(Session::get('couponAmount')); ?>">
                  </div>
                  <div class="control-group">
                      <label class="control-label"><?php echo e($address->name); ?>,<?php echo e($address->address); ?>,<?php echo e($address->city); ?>,<?php echo e($address->state); ?>,<?php echo e($address->country); ?>,(<?php echo e($address->mobile); ?>)</label>
                  </div>
                      
              </td>
              <td><a href="<?php echo e(url('add-edit-dalivary-address/'.$address->id)); ?>">Edit</a> / <a class="delivaryAddressDelete" href="<?php echo e(url('delete-dalivary-address/'.$address->id)); ?>">Delete</a></td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <table class="table table-bordered">
            <thead>
              <tr>
                <th>Product</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Category<br>Product<br>Discount</th>
                <th>Sub Total</th>
              </tr>
            </thead>
            <tbody>
                <?php $total_price =0; ?>
                <?php $__currentLoopData = $userCartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $attrPrice = Product::getDiscountedAttrPrice($item['product_id'],$item['size']); ?>
                <tr>
                  <td> <img width="60" src="<?php echo e(asset('backEnd/images/products/small/'.$item['product']['main_image'])); ?>" alt=""/></td>
                  <td><?php echo e($item['product']['product_name']); ?><br/>Color : <?php echo e($item['product']['product_color']); ?> | Code : <?php echo e($item['product']['product_code']); ?><br/>Size : <?php echo e($item['size']); ?></td>
                  <td> <?php echo e($item['quantity']); ?> </div>
                  </td>
                  <td>৳.<?php echo e($attrPrice['product_price']); ?></td>
                  <?php
                    $totaldiscount = round($attrPrice['discount']*$item['quantity']);
                    
                    
                    $subtotal = $attrPrice['product_price'] * $item['quantity'] - $totaldiscount;
                    // $subtotalall = $subtotal - $totaldiscount;
                  ?>
                  <td>৳.<?php echo e(($totaldiscount)); ?></td>
                  <td>৳.<?php echo e(($subtotal)); ?></td>
                </tr>
                <?php $total_price = $total_price + ( $attrPrice['final_price'] * $item['quantity']); 
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td colspan="5" style="text-align:right">Total Price:	</td>
                  <td> ৳.<?php echo e($total_price); ?></td>
              </tr>
              <tr>
                <td colspan="5" style="text-align:right">Coupon Discount:	</td>
                <td class="couponAmount"> 
                  <?php if(Session::has('couponAmount')): ?>
                    ৳. - <?php echo e(Session::get('couponAmount')); ?>

                  <?php else: ?> 
                    ৳. 0
                  <?php endif; ?> 
                </td>
            </tr>
            <tr>
                <td colspan="5" style="text-align:right">Shipping Charges:	</td>
                <td class="shipping_charges">  ৳. 0</td>
            </tr>
            <tr>
                <td colspan="5" style="text-align:right"><strong>GRAND TOTAL (৳.<?php echo e($total_price); ?> - <span class="couponAmount"> <?php if(Session::get('couponAmount')): ?><?php echo e(Session::get('couponAmount')); ?> <?php else: ?> ৳. 0 <?php endif; ?></span> + <span class="shipping_charges"></span>)  =</strong></td>
                <td class="label label-important" style="display:block"> <strong class="grand_total"> ৳.<?php echo e($grand_total = $total_price - Session::get('couponAmount')); ?> <?php Session::put('grand_total',$grand_total); ?></strong></td>
                
            </tr>
  </table>

  <table class="table table-bordered">
    <tbody>
        <tr>
          <td>
            <div class="control-group">
              <label class="control-label"><strong> PAYMENT METHODS :</strong> </label>
              <div class="controls">
                <span>
                  <input  style="margin-right:5px; margin-top:-2px;" type="radio" name="payment_getwaya" id="COD" value="COD"><strong>COD</strong> &nbsp;&nbsp;
                  <input  style="margin-right:5px; margin-top:-2px;" type="radio" name="payment_getwaya" id="Paypal" value="Paypal"><strong>Paypal</strong>
                </span>
              </div>
            </div>
          </td>
        </tr>
      </tbody>
  </table>

  <a href="<?php echo e(url('/cart')); ?>" class="btn btn-large"><i class="icon-arrow-left"></i> Back to Cart </a>
  <button  type="submit" class="btn btn-large pull-right">Place Order <i class="icon-arrow-right"></i></button>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\products\checkout.blade.php ENDPATH**/ ?>