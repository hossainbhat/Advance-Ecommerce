<!DOCTYPE html>
<html lang="en">
<head>
    <title>E-commerce Contact</title>
</head>
<body>
    <table>
        <tr>
            <td>Dear <?php echo e($name); ?></td>
        </tr>
        <tr>
            <td>Enwuery from E-commerce Website. Enqery details are as below</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Name: <?php echo e($name); ?></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Email: <?php echo e($email); ?></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Subject: <?php echo e($subject); ?></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Message: <?php echo e($comment); ?></td>
        </tr>
        <tr>
            <td>E-commerce Website</td>
        </tr>

    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\emails\contact.blade.php ENDPATH**/ ?>