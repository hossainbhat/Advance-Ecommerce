	<!--plugins-->
	<link href="<?php echo e(asset('backEnd/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('backEnd/plugins/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('backEnd/plugins/metismenu/css/metisMenu.min.css')); ?>" rel="stylesheet" />
	<!-- loader-->
	<link href="<?php echo e(asset('backEnd/css/pace.min.css')); ?>" rel="stylesheet" />
	<script src="<?php echo e(asset('backEnd/js/pace.min.js')); ?>"></script>
	<!-- Bootstrap CSS -->
	<link href="<?php echo e(asset('backEnd/css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&amp;display=swap" rel="stylesheet">
	<link href="<?php echo e(asset('backEnd/css/app.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('backEnd/css/icons.css')); ?>" rel="stylesheet">
	<!-- Theme Style CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('backEnd/css/dark-theme.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('backEnd/css/semi-dark.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('backEnd/css/header-colors.css')); ?>" />
	<!-- sweetalert -->
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\layouts\admin_layouts\header_script.blade.php ENDPATH**/ ?>