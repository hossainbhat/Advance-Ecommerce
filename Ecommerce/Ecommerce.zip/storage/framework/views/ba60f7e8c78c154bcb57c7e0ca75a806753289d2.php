
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('front_css'); ?>
<style>
form.cmxform label.error, label.error {
    color: red;
    font-style: italic;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">Dalivary Address</li>
    </ul>
	<h3> <?php echo e($title); ?></h3>	
	<hr class="soft"/>
	
	<div class="row">
	<?php if(Session::has('success_message')): ?>
     <div class="alert alert-success" role="alert">
       <?php echo e(Session::get('success_message')); ?>

       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>
     <?php Session::forget('success_message') ?>
     <?php endif; ?>
	<?php if(Session::has('error_message')): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e(Session::get('error_message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php Session::forget('error_message') ?>
	<?php endif; ?>
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>
    
		<div class="span4">
			<div class="well">
			Dalivary Address details.<br/><br/><br/>
			<form id="dalivaryAddressForm" <?php if(empty($address->id)): ?> action="<?php echo e(url('add-edit-dalivary-address')); ?>" <?php else: ?> action="<?php echo e(url('add-edit-dalivary-address/'.$address->id)); ?>" <?php endif; ?> method="post">
				<?php echo csrf_field(); ?>
			  <div class="control-group">
				<label class="control-label" for="name"> Name</label>
				<div class="controls">
				  <input class="span3" name="name"  type="text" id="name"  placeholder="Enter Name" <?php if(isset($address->name)): ?> value="<?php echo e($address->name); ?>" <?php else: ?> value="<?php echo e(old('name')); ?>" <?php endif; ?> >
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="address"> Address</label>
				<div class="controls">
				  <input class="span3" name="address"  type="text" id="address"  placeholder="Enter address"  <?php if(isset($address->address)): ?> value="<?php echo e($address->address); ?>" <?php else: ?> value="<?php echo e(old('address')); ?>" <?php endif; ?>>
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="city"> City</label>
				<div class="controls">
				  <input class="span3" name="city"  type="text" id="city"  placeholder="Enter city" <?php if(isset($address->city)): ?> value="<?php echo e($address->city); ?>" <?php else: ?> value="<?php echo e(old('city')); ?>" <?php endif; ?>>
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="state"> State</label>
				<div class="controls">
				  <input class="span3" name="state"  type="text" id="state"  placeholder="Enter state"  <?php if(isset($address->state)): ?>  value="<?php echo e($address->state); ?>" <?php else: ?> value="<?php echo e(old('state')); ?>" <?php endif; ?>>
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="country"> Country</label>
				<div class="controls">
					<select class="span3" name="country" id="country">
						<option value="">select country</option>
						<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($country->country_name); ?>" <?php if($country->country_name == $address['country']): ?> selected="" <?php elseif($country->country_name == old('country')): ?> selected="" <?php endif; ?>><?php echo e($country->country_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="pincode"> Pincode</label>
				<div class="controls">
				  <input class="span3" name="pincode"  type="text" id="pincode"  placeholder="Enter pincode" <?php if(isset($address->pincode)): ?> value="<?php echo e($address->pincode); ?>"  <?php else: ?> value="<?php echo e(old('pincode')); ?>" <?php endif; ?>>
				</div>
			  </div>
              <div class="control-group">
				<label class="control-label" for="mobile">Mobile</label>
				<div class="controls">
				  <input class="span3" name="mobile"  type="text" id="mobile"  placeholder="Enter Mobile"   <?php if(isset($address->mobile)): ?> value="<?php echo e($address->mobile); ?>"  <?php else: ?> value="<?php echo e(old('mobile')); ?>" <?php endif; ?>>
				</div>
			  </div>
			  <div class="controls">
			    <button type="submit" class="btn block">submit</button>
			    <a style="float:right;" href="<?php echo e(url('checkout')); ?>" class="btn block">Back</a>
			  </div>
			</form>
		</div>
		</div>
		
	
		</div>
	</div>	
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\products\add_edit_dalivary_address.blade.php ENDPATH**/ ?>