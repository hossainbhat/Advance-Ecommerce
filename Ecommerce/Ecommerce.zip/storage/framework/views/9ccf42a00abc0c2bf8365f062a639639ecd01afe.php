
<?php $__env->startSection('title',$name); ?>
<?php $__env->startSection('script_css'); ?>
<link href="<?php echo e(asset('backEnd/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('backEnd/plugins/select2/css/select2-bootstrap4.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-12 mx-auto">
						<h6 class="mb-0 text-uppercase"><?php echo e($name); ?></h6>                        
						<a href="<?php echo e(url('admin/products')); ?>" style="float:right; margin-top:-30px;"><button class="btn btn-sm btn-success">Product List <i class="lni lni-list"></i></button></a>

						<hr>
						<div class="card">
							<div class="card-body">
								<div class="p-4 border rounded">
										<?php if(Session::has('error_message')): ?>
											<div class="alert alert-danger border-0 bg-success alert-dismissible fade show">
												<div class="text-white"><?php echo e(Session::get('error_message')); ?></div>
												<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											</div>
										<?php endif; ?>
										<?php if($errors->any()): ?>
											<div class="alert alert-danger">
												<ul>
													<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li><?php echo e($error); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</div>
										<?php endif; ?>
									<form class="row g-3 needs-validation"  method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    
                                        <div class="col-md-6">
                                            <div class="mb-3" data-select2-id="21">
										        <label class="form-label">Brand Name</label>
                                                <select name="brand_id" id="brand_id" class="brand-select select2-hidden-accessible" data-select2-id="1" tabindex="-1" aria-hidden="true">
                                                <option value="0">Select</option>
												<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($brand['id']); ?>" <?php if(!empty($productdata['brand_id']) && $productdata['brand_id'] == $brand['id']): ?> selected="" <?php endif; ?>><?php echo e($brand['name']); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
								            </div>
                                        </div>
										<div class="col-md-6">
                                            <div class="mb-3" data-select2-id="21">
										        <label class="form-label">Category Name</label>
                                                <select name="category_id" id="category_id" class="category-select select2-hidden-accessible" data-select2-id="5" tabindex="-5" aria-hidden="true">
                                                <option value="0">Select</option>
												<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<optgroup label="<?php echo e($section['name']); ?>"></optgroup>	 
													<?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($category['id']); ?>" <?php if(!empty(@old('category_id')) && $category['id'] == @old('category_id')): ?> selected=""  <?php elseif(!empty($productdata['category_id']) && $productdata['category_id'] == $category['id']): ?> selected="" <?php endif; ?>>&nbsp;&nbsp;--&nbsp;<?php echo e($category['name']); ?></option>
														<?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<option value="<?php echo e($subcategory['id']); ?>" <?php if(!empty(@old('category_id')) && $subcategory['id'] ==@old('category_id')): ?> selected="" <?php elseif(!empty($productdata['category_id']) && $productdata['category_id'] == $subcategory['id']): ?> selected="" <?php endif; ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;<?php echo e($subcategory['name']); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
								            </div>
                                        </div>
                                        <div class="col-md-6">
											<label for="product_name" class="form-label">Product Name</label>
											<input type="text" name="product_name" class="form-control" id="product_name" placeholder="Enter product_name" <?php if(!empty($productdata['product_name'])): ?> value="<?php echo e($productdata['product_name']); ?>" <?php else: ?> value="<?php echo e(old('product_name')); ?>" <?php endif; ?>>
										</div>
										<div class="col-md-6">
											<label for="product_code" class="form-label">Product Code</label>
											<input type="text" name="product_code" class="form-control" id="product_code" placeholder="Enter product_code" <?php if(!empty($productdata['product_code'])): ?> value="<?php echo e($productdata['product_code']); ?>" <?php else: ?> value="<?php echo e(old('product_code')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-md-6">
											<label for="product_price" class="form-label">Product Price</label>
											<input type="text" name="product_price" class="form-control" id="product_price" placeholder="Enter product_price" <?php if(!empty($productdata['product_price'])): ?> value="<?php echo e($productdata['product_price']); ?>" <?php else: ?> value="<?php echo e(old('product_price')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-md-6">
											<label for="product_color" class="form-label">Product Color</label>
											<input type="text" name="product_color" class="form-control" id="product_color" placeholder="Enter product_color" <?php if(!empty($productdata['product_color'])): ?> value="<?php echo e($productdata['product_color']); ?>" <?php else: ?> value="<?php echo e(old('product_color')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-md-6">
											<label for="product_discount" class="form-label">Product Discount(%)</label>
											<input type="text" name="product_discount" class="form-control" id="product_discount" placeholder="Enter product_discount" <?php if(!empty($productdata['product_discount'])): ?> value="<?php echo e($productdata['product_discount']); ?>" <?php else: ?> value="<?php echo e(old('product_discount')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-md-6">
											<label for="product_weight" class="form-label">Product Weight(gm)</label>
											<input type="text" name="product_weight" class="form-control" id="product_weight" placeholder="Enter product_weight" <?php if(!empty($productdata['product_weight'])): ?> value="<?php echo e($productdata['product_weight']); ?>" <?php else: ?> value="<?php echo e(old('product_weight')); ?>" <?php endif; ?>>
										</div>
                                        <div class="col-md-6">
                                            <div class="mb-3" data-select2-id="21">
										        <label class="form-label">Sleeve Name</label>
                                                <select name="sleeve" id="sleeve" class="sleeve-select select2-hidden-accessible" data-select2-id="2" tabindex="-2" aria-hidden="true">
                                                <option value="0">Select</option>
												<?php $__currentLoopData = $sleeveArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sleeve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($sleeve); ?>" <?php if(!empty($productdata['sleeve']) && $productdata['sleeve'] == $sleeve): ?> selected="" <?php endif; ?>><?php echo e($sleeve); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
								            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3" data-select2-id="21">
										        <label class="form-label">Fabric Name</label>
                                                <select name="fabric" id="fabric" class="fabric-select select2-hidden-accessible" data-select2-id="6" tabindex="-6" aria-hidden="true">
                                                <option value="0">Select</option>
												<?php $__currentLoopData = $fabricArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fabric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($fabric); ?>" <?php if(!empty($productdata['fabric']) && $productdata['fabric'] == $fabric): ?> selected="" <?php endif; ?>><?php echo e($fabric); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
								            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3" data-select2-id="21">
										        <label class="form-label">Pattern Name</label>
                                                <select name="pattern" id="pattern" class="pattern-select select2-hidden-accessible" data-select2-id="7" tabindex="-7" aria-hidden="true">
                                                <option value="0">Select</option>
												<?php $__currentLoopData = $patternArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pattern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($pattern); ?>" <?php if(!empty($productdata['pattern']) && $productdata['pattern'] == $pattern): ?> selected="" <?php endif; ?>><?php echo e($pattern); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
								            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3" data-select2-id="21">
										        <label class="form-label">Fit Name</label>
                                                <select name="fit" id="fit" class="fit-select select2-hidden-accessible" data-select2-id="3" tabindex="-3" aria-hidden="true">
                                                <option value="0">Select</option>
												<?php $__currentLoopData = $fitArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($fit); ?>"  <?php if(!empty($productdata['fit']) && $productdata['fit'] == $fit): ?> selected="" <?php endif; ?>><?php echo e($fit); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
								            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3" data-select2-id="21">
										        <label class="form-label">Occasion Name</label>
                                                <select name="occasion" id="occasion" class="occasion-select select2-hidden-accessible" data-select2-id="4" tabindex="-4" aria-hidden="true">
                                                <option value="0">Select</option>
												<?php $__currentLoopData = $occsionArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($occasion); ?>" <?php if(!empty($productdata['occasion']) && $productdata['occasion'] == $occasion): ?> selected="" <?php endif; ?>><?php echo e($occasion); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
								            </div>
                                        </div>
                                       
                                        <div class="col-md-6">
                                            <label for="main_image" class="form-label">Product Image</label>
                                            <input class="form-control" name="main_image" type="file" id="main_image"> 
											<?php if(!empty($productdata['main_image'])): ?>
											<div style="height: 90px;">
												<img style="width: 80px; margin-top: 5px;" src="<?php echo e(asset('backend/images/products/small/'.$productdata['main_image'])); ?>" >
												&nbsp;
												<a class="confirmDelete" record="product-image" recoedid="<?php echo e($productdata['id']); ?>" href="javascript:void('0')">Delete</a>
											</div>
											<?php endif; ?>                
                                        </div>
                                        <div class="col-md-6">
                                            <label for="product_video" class="form-label">Product Video</label>
                                            <input class="form-control" name="product_video" type="file" id="product_video"> 
											<?php if(!empty($productdata['product_video'])): ?>
												<div><a href="<?php echo e(url('videos/'.$productdata['product_video'])); ?>" download="">Download</a>&nbsp;|&nbsp;<a class="confirmDelete" record="product-video" recoedid="<?php echo e($productdata['id']); ?>" href="javascript:void('0')">Delete</a></div>
											<?php endif; ?>                
                                        </div>

                                        <div class="col-6">
                                            <label for="description" class="form-label">Product Description</label>
                                            <textarea class="form-control" name="description" id="editor" placeholder="description..." rows="3"><?php if(!empty($productdata['description'])): ?> <?php echo e($productdata['description']); ?> <?php else: ?> <?php echo e(old('description')); ?> <?php endif; ?></textarea>
									    </div>
                                        <div class="col-6">
                                            <label for="wash_care" class="form-label">Wash Care</label>
                                            <textarea class="form-control" name="wash_care" id="editor2" placeholder="wash_care..." rows="3"><?php if(!empty($productdata['wash_care'])): ?> <?php echo e($productdata['wash_care']); ?> <?php else: ?> <?php echo e(old('wash_care')); ?> <?php endif; ?></textarea>
									    </div>
                                        
                                        <div class="col-6">
                                            <label for="meta_title" class="form-label">Meta Title</label>
											<input type="text" name="meta_title" class="form-control" id="meta_title" placeholder="Enter meta_title" <?php if(!empty($productdata['meta_title'])): ?> value="<?php echo e($productdata['meta_title']); ?>" <?php else: ?> value="<?php echo e(old('meta_title')); ?>" <?php endif; ?>>
									    </div>
                                        <div class="col-6">
                                            <label for="meta_description" class="form-label">Meta Description</label>
                                            <textarea class="form-control" name="meta_description" id="editor3" placeholder="meta_description..." rows="3"><?php if(!empty($productdata['meta_description'])): ?> <?php echo e($productdata['meta_description']); ?> <?php else: ?> <?php echo e(old('meta_description')); ?> <?php endif; ?></textarea>
									    </div>
										<div class="col-6">
                                            <label for="meta_keywords" class="form-label">Meta Keywords</label>
											<input type="text" name="meta_keywords" class="form-control" id="meta_keywords" placeholder="Enter meta_keywords" <?php if(!empty($productdata['meta_keywords'])): ?> value="<?php echo e($productdata['meta_keywords']); ?>" <?php else: ?> value="<?php echo e(old('meta_keywords')); ?>" <?php endif; ?>>
									    </div>
										<div class="form-group">
											<label for="is_featured">Featured</label>
											<input type="checkbox" name="is_featured" id="is_featured" value="Yes" <?php if(!empty($productdata['is_featured']) && $productdata['is_featured'] =="Yes"): ?> checked="" <?php endif; ?>>
										</div>
										<div class="col-12">
											<button class="btn btn-primary" type="submit"><?php echo e($name); ?></button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--end row-->
			</div>
		</div>	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_js'); ?>
<script src="<?php echo e(asset('backEnd/plugins/select2/js/select2.min.js')); ?>"></script>
<script>
		$('.brand-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
        $('.sleeve-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
        $('.fit-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
        $('.occasion-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
        $('.category-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
        $('.fabric-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
        $('.pattern-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
     
	</script>

<script src="https://cdn.ckeditor.com/ckeditor5/34.1.0/classic/ckeditor.js"></script>

<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        } );
		ClassicEditor
        .create( document.querySelector( '#editor2' ) )
        .catch( error => {
            console.error( error );
        } );
		ClassicEditor
        .create( document.querySelector( '#editor3' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\product\add_edit_product.blade.php ENDPATH**/ ?>