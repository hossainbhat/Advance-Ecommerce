<!doctype html>
<html lang="en" class="color-sidebar sidebarcolor6">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<!--favicon-->
	<link rel="icon" href="<?php echo e(asset('backEnd/images/favicon-32x32.png')); ?>" type="image/png" />
	<?php echo $__env->make("layouts.admin_layouts.header_script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent("script_css"); ?>
	<title><?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?> </title>
</head>

<body>
	<!--wrapper-->
	<div class="wrapper">
		<!--sidebar wrapper -->
        <?php echo $__env->make("layouts.admin_layouts.admin_sitebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--end sidebar wrapper -->
		<!--start header -->
		<?php echo $__env->make("layouts.admin_layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--end header -->
		<!--start page wrapper -->
		<?php echo $__env->yieldContent("content"); ?>
		<!--end page wrapper -->
		<!--start overlay-->
		<div class="overlay toggle-icon"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
        <?php echo $__env->make("layouts.admin_layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<!--end wrapper-->
	<!-- Bootstrap JS -->
	<?php echo $__env->make("layouts.admin_layouts.footer_script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent("script_js"); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\layouts\admin_layouts\admin_layout.blade.php ENDPATH**/ ?>