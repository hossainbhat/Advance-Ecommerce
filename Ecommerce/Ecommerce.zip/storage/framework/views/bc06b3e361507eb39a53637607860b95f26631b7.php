
<?php $__env->startSection('title','Oders List'); ?>
<?php $__env->startSection('script_css'); ?>
<link href="<?php echo e(asset('backEnd/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<h6 class="mb-0 text-uppercase">Order List</h6>
				<hr/>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
						  <?php if(Session::has('success_message')): ?>
							<div class="alert alert-success border-0 bg-success alert-dismissible fade show">
								<div class="text-white"><?php echo e(Session::get('success_message')); ?></div>
								<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
							</div>
						  <?php endif; ?>
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>Order Id</th>
										<th>Order Date</th>
										<th>Name</th>
										<th>Email</th>
										<th>Product</th>
										<th>Amount</th>
										<th>Status</th>
										<th>Payment</th>
										<th width="10%">Action</th>
									</tr>
								</thead>
								<tbody>
								<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
										<td><?php echo e($order['id']); ?></td>
                                        <td><?php echo e(date('d-M-Y', strtotime($order['created_at']))); ?></td>
										<td><?php echo e($order['name']); ?></td>
										<td><?php echo e($order['email']); ?></td>
										<td>
                                        <?php $__currentLoopData = $order['orders_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($pro['product_code']); ?> (<?php echo e($pro['product_qty']); ?>) <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
										<td><?php echo e($order['grand_total']); ?></td>
										<td><?php echo e($order['order_status']); ?></td>
										<td><?php echo e($order['payment_method']); ?></td>
										<td>
										<a href="<?php echo e(url('admin/order/'.$order['id'])); ?>"><i class="btn btn-info btn-sm fadeIn animated bx bx-file-blank"></i></a>  
										&nbsp;
										<?php if($order['order_status']=="Shipped" || $order['order_status']=="Delivered"): ?>
										<a href="<?php echo e(url('admin/view-order-invoice/'.$order['id'])); ?>" target="__blanck"><i class="btn btn-success btn-sm fadeIn animated bx bx-printer"></i></a>  
										&nbsp;
										<a href="<?php echo e(url('admin/print-pdf-invoice/'.$order['id'])); ?>" target="__blanck"><i class="btn btn-primary btn-sm fadeIn animated bx bx-save"></i></a>  
										<?php endif; ?> 
									</tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								</tbody>
							</table>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		<!--end page wrapper -->
		
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script_js"); ?>
<script src="<?php echo e(asset('backEnd/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\admin\orders\orders.blade.php ENDPATH**/ ?>