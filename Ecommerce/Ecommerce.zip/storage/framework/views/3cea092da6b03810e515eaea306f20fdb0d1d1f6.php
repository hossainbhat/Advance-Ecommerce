<table class="table table-bordered">
        <thead>
        <tr>
            <th>Product</th>
            <th>Description</th>
            <th>Price</th>
            <th>View / Delete</th>
        </tr>
        </thead>
        <tbody>
            
            <?php $__currentLoopData = $userWishlistItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td> <img width="60" src="<?php echo e(asset('backEnd/images/products/small/'.$item['product']['main_image'])); ?>" alt=""/></td>
            <td><?php echo e($item['product']['product_name']); ?><br/>Color : <?php echo e($item['product']['product_color']); ?> | Code : <?php echo e($item['product']['product_code']); ?></td>
            <td>৳.<?php echo e($item['product']['product_price']); ?></td>
            <td>
                <div class="input-append">
                
                    <a href="<?php echo e(url($item['product']['id'])); ?>"><button class="btn btnItemUpdate" type="button"><i class="fas fa-file"></i></button></a>
                    <button class="btn btn-danger wishlistItemDelete" data-wishlistid="<?php echo e($item['id']); ?>" type="button"><i class="fas fa-times"></i></button>
                </div>
            </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </table><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views\front\products\wishlist_item.blade.php ENDPATH**/ ?>