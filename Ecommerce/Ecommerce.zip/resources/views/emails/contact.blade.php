<!DOCTYPE html>
<html lang="en">
<head>
    <title>E-commerce Contact</title>
</head>
<body>
    <table>
        <tr>
            <td>Dear {{$name}}</td>
        </tr>
        <tr>
            <td>Enwuery from E-commerce Website. Enqery details are as below</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Name: {{$name}}</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Email: {{$email}}</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Subject: {{$subject}}</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Message: {{$comment}}</td>
        </tr>
        <tr>
            <td>E-commerce Website</td>
        </tr>

    </table>
</body>
</html>